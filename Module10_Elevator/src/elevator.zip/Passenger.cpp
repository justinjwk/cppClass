#include "Passenger.h"


Passenger::Passenger(int value) {
	destination_floor = value;
}

Passenger::~Passenger() {

}

void Passenger::addWaitTime(int wt) {
	wait_time = wt;
}

int& Passenger::getWaitTime() {
	return wait_time;
}

int& Passenger::getTravelTime() {
	return travel_time;
}

void Passenger::addTravelTime(int tt) {
	travel_time = tt;
}

void Passenger::update() {

}

int& Passenger::getDestinationFloor() {
	return destination_floor;
}
